import java.util.Scanner;
import java.util.Arrays;

public class main {
    public static void main(String[]arhs) {
       
String[][] questions = {
    {"one","two","three"},
    {"four","five","six"}
    };

System.out.println("Hi there, there are two categories here pick wisely ");

System.out.println("input 1 or 2 ");
Scanner scanner = new Scanner(System.in);
int choice = scanner.nextInt();

if (choice == 1) {
    System.out.println(questions[0][2]);
}
    }
}
